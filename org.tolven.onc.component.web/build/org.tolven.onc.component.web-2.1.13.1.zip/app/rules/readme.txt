This directory contains rule files to be added to the database and which will be used to process messages.
Rules are uploaded during configPhase3.